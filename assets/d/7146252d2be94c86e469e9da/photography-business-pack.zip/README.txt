Photography Business Pack — Booking Contract, Invoice & Shot List Planner
=========================================================================

Book clients under a real contract, bill professionally, and never miss the shot that mattered.

INCLUDED FILES:
- photography-booking-contract-template.xlsx — Booking contract — session terms, deposit, signature lines
- photography-invoice-template.xlsx — Invoice template — packages, add-ons, auto totals
- photography-shot-list-planner.xlsx — Shot list planner — plan every must-get shot before the session

HOW TO USE:
1. Open any file in Microsoft Excel, or upload it to Google Drive and open with Google Sheets.
2. Start with the START HERE tab in each workbook — it explains the color key and workflow.
3. Type only in the yellow cells. All totals and formulas are automatic and unlocked.

LICENSE: For the purchaser's own business use. Resale or redistribution of the files is prohibited.
Ren Delivers — rendelivers.com