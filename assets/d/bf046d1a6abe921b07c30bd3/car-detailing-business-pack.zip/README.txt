Car Detailing Business Pack — Condition Checklist, Package Price Sheet & Invoice
================================================================================

Price packages, document vehicle condition, and bill like a pro detailing shop.

INCLUDED FILES:
- car-detailing-condition-checklist.xlsx — 63-point vehicle condition checklist — document pre-existing damage before you start
- car-detailing-package-price-sheet.xlsx — Detail package price sheet + quote calculator
- car-detailing-invoice-template.xlsx — Invoice template — packages and add-ons, auto totals

HOW TO USE:
1. Open any file in Microsoft Excel, or upload it to Google Drive and open with Google Sheets.
2. Start with the START HERE tab in each workbook — it explains the color key and workflow.
3. Type only in the yellow cells. All totals and formulas are automatic and unlocked.

LICENSE: For the purchaser's own business use. Resale or redistribution of the files is prohibited.
Ren Delivers — rendelivers.com