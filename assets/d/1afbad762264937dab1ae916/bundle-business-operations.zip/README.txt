Contractor Business Operations Bundle — README
==============================================

Thank you for your purchase from rendelivers!

WHAT'S INSIDE
1. contractor-invoice-template.xlsx
   Professional client invoice with line items, tax toggle, and Balance Due block.
2. change-order-template.xlsx
   Document and price every scope change mid-job with client signatures.
3. daily-field-report-template.xlsx
   Daily jobsite log: weather, crew on site, work completed, deliveries, safety notes.
4. punch-list-template.xlsx
   Track every item to closeout: task, room, owner, due date, status.
5. subcontractor-bid-comparison.xlsx
   Line up sub bids side by side and spot the real lowest number.
6. job-cost-tracker.xlsx
   Compare estimated vs. actual costs per job in real time.
7. crew-time-tracking-template.xlsx
   Weekly crew hours by day, employee, and job — built to feed payroll.
8. equipment-maintenance-log.xlsx
   Service history, hours, and maintenance schedules for every machine.

HOW TO OPEN
- Microsoft Excel: double-click any .xlsx file, or File > Open.
- Google Sheets: upload the .xlsx to Google Drive, right-click >
  Open with > Google Sheets. All formulas carry over.
- Type only in the highlighted/yellow cells; everything else calculates
  automatically. Nothing is locked or password-protected.
- Print or export to PDF straight from Excel or Sheets for clients,
  subs, and your records.

BUNDLE SAVINGS
You save $84.65 vs buying separately ($119.60).

LICENSE
- Your purchase ($34.95) covers use in your own business,
  including your whole company/crew.
- You may NOT resell, share, or redistribute the files themselves.

SUPPORT
- Questions about a template? Message us through your Etsy purchase
  and we'll help you get it working.

— rendelivers
