Dog Grooming Business Pack — Intake Form, Appointment Scheduler & Invoice
=========================================================================

Everything a grooming shop or mobile groomer needs on paper: intake, scheduling, and billing in one matching set.

INCLUDED FILES:
- dog-grooming-intake-form.xlsx — Client & pet intake form with service history log
- dog-grooming-appointment-scheduler.xlsx — Appointment schedule grid + waitlist
- dog-grooming-invoice-template.xlsx — Invoice template — services, add-ons, auto totals

HOW TO USE:
1. Open any file in Microsoft Excel, or upload it to Google Drive and open with Google Sheets.
2. Start with the START HERE tab in each workbook — it explains the color key and workflow.
3. Type only in the yellow cells. All totals and formulas are automatic and unlocked.

LICENSE: For the purchaser's own business use. Resale or redistribution of the files is prohibited.
Ren Delivers — rendelivers.com