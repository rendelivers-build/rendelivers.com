Contractor Starter Pack — README
================================

Thank you for your purchase from rendelivers!

WHAT'S INSIDE
1. contractor-estimate-bid-calculator.xlsx
   9-tab estimate & bid calculator: room measurements in, costed estimate and print-ready client quote out. Includes bid summary, item library, example project, and change-order forms.
2. construction-schedule-gantt-template.xlsx
   Gantt-style project scheduler: lay out every phase of the job on a timeline for you, your crew, and your client.
3. contractor-invoice-template.xlsx
   Professional invoice with line items, tax toggle, and Balance Due block. Print or export to PDF in two clicks.
4. change-order-template.xlsx
   Change order forms with cost breakdown and signature lines — document and price every scope change before work starts.

HOW TO OPEN
- Microsoft Excel: double-click any .xlsx file, or File > Open.
- Google Sheets: upload the .xlsx to Google Drive, right-click >
  Open with > Google Sheets. All formulas carry over.
- Type only in the highlighted/yellow cells; everything else calculates
  automatically. Nothing is locked or password-protected.
- Print or export to PDF straight from Excel or Sheets for clients,
  subs, and your records.

BUNDLE SAVINGS
You save $34.85 vs buying separately ($59.80).

LICENSE
- Your purchase ($24.95) covers use in your own business,
  including your whole company/crew.
- You may NOT resell, share, or redistribute the files themselves.

SUPPORT
- Questions about a template? Message us through your Etsy purchase
  and we'll help you get it working.

— rendelivers
