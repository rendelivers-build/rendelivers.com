Complete Trade Estimator Collection — README
============================================

Thank you for your purchase from rendelivers!

WHAT'S INSIDE
1. contractor-estimate-bid-calculator.xlsx
   Flagship general estimator: room calculator, 40-line estimate sheet, item library, client quote, change-order forms, bid summary.
2. plumbing-estimate-template.xlsx
   Plumbing estimate template with trade-specific item library.
3. electrical-estimate-template.xlsx
   Electrical estimate template with trade-specific item library.
4. hvac-estimate-template.xlsx
   HVAC estimate template with trade-specific item library.
5. roofing-estimate-template.xlsx
   Roofing estimate template with trade-specific item library.
6. siding-estimate-template.xlsx
   Siding estimate template with trade-specific item library.
7. windows-doors-estimate-template.xlsx
   Windows & doors estimate template with trade-specific item library.
8. deck-patio-estimate-template.xlsx
   Deck & patio estimate template with trade-specific item library.
9. landscaping-fencing-estimate-template.xlsx
   Landscaping & fencing estimate template with trade-specific item library.
10. excavation-grading-estimate-template.xlsx
   Excavation & grading estimate template with trade-specific item library.
11. concrete-masonry-estimate-template.xlsx
   Concrete & masonry estimate template with trade-specific item library.
12. painting-estimate-template.xlsx
   Painting estimate template with trade-specific item library.
13. drywall-estimate-template.xlsx
   Drywall estimate template with trade-specific item library.
14. flooring-estimate-template.xlsx
   Flooring estimate template with trade-specific item library.
15. tile-estimate-template.xlsx
   Tile estimate template with trade-specific item library.
16. insulation-estimate-template.xlsx
   Insulation estimate template with trade-specific item library.
17. kitchen-remodel-estimate-template.xlsx
   Kitchen remodel estimate template with trade-specific item library.
18. bathroom-remodel-estimate-template.xlsx
   Bathroom remodel estimate template with trade-specific item library.
19. handyman-estimate-template.xlsx
   Handyman estimate template with service library (hourly, half-day, flat-rate).

HOW TO OPEN
- Microsoft Excel: double-click any .xlsx file, or File > Open.
- Google Sheets: upload the .xlsx to Google Drive, right-click >
  Open with > Google Sheets. All formulas carry over.
- Type only in the highlighted/yellow cells; everything else calculates
  automatically. Nothing is locked or password-protected.
- Print or export to PDF straight from Excel or Sheets for clients,
  subs, and your records.

BUNDLE SAVINGS
You save $224.10 vs buying separately ($284.05).

LICENSE
- Your purchase ($59.95) covers use in your own business,
  including your whole company/crew.
- You may NOT resell, share, or redistribute the files themselves.

SUPPORT
- Questions about a template? Message us through your Etsy purchase
  and we'll help you get it working.

— rendelivers
