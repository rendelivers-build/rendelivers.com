House Cleaning Business Pack — Invoice, Recurring Schedule & Room Checklist
===========================================================================

Run a cleaning business that looks professional on paper: bill clients, schedule recurring cleans, and clean to the same checklist every visit.

INCLUDED FILES:
- house-cleaning-invoice-template.xlsx — Invoice template — service lines, auto totals, deposit & balance due
- house-cleaning-recurring-schedule.xlsx — Recurring client schedule + monthly calendar for weekly/biweekly cleans
- house-cleaning-room-checklist.xlsx — 56-point room-by-room cleaning checklist

HOW TO USE:
1. Open any file in Microsoft Excel, or upload it to Google Drive and open with Google Sheets.
2. Start with the START HERE tab in each workbook — it explains the color key and workflow.
3. Type only in the yellow cells. All totals and formulas are automatic and unlocked.

LICENSE: For the purchaser's own business use. Resale or redistribution of the files is prohibited.
Ren Delivers — rendelivers.com